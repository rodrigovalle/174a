Rodrigo Valle
104 494 120

The project is still called Bee Scene at the top of the page, I didn't want to
mess anything up by changing it.

The flat shaded edges/custom shape/custom texture is present as the lego
figure's torso. The texture is that of a shirt, it's subtle but it's there. You
can pause the animation when the figure runs by at the beginning to view it. The
edges are flat shaded, although it might be hard to tell under that particular
lighting. Rest assured, I checked to make sure, please see some of the other
shots with better lighting if you need further confirmation.

The hierarchical aspect comes from the figure's arm and wrist movement (2
pivots).

The frame rate can be seen by pressing 't' and scrolling with the arrow keys. It
updates 10 times every second, so you can have the chance to actually read it.

The most diffcult part of this project was getting all of the animations
correct, I had to make sure that, at each animation "seam" that the lego
character's limbs were appropriately aligned so that they wouldn't appear jumpy.
The jump sequence alone is at least 3 cuts spliced together to make it seem like
one continuous sequence.
